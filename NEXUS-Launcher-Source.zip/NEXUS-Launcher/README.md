# NEXUS Launcher — proyecto para Acode + GitHub Actions

Proyecto Android nativo con Kotlin, Jetpack Compose y Material 3. No necesita Android Studio para editarlo ni para compilarlo: GitHub Actions instala Gradle y compila el APK en la nube.

## Requisitos
- Acode en Android.
- Cuenta de GitHub.
- Conexión a Internet.

## Estructura
- `app/`: aplicación Android.
- `.github/workflows/build.yml`: compilación automática en GitHub Actions.
- `build.gradle.kts`, `settings.gradle.kts`, `gradle.properties`: configuración Gradle.

## Abrir en Acode
1. Extrae el ZIP con el administrador de archivos del teléfono.
2. En Acode, abre la carpeta extraída `NEXUS-Launcher` como proyecto.
3. No cambies los nombres ni la ubicación de las carpetas.

## Subir a GitHub desde Acode
Abre el terminal integrado de Acode estando en la carpeta raíz del proyecto. Comprueba que aparecen `app`, `.github`, `build.gradle.kts` y `settings.gradle.kts` con `ls`.

Instala Git en el terminal Alpine de Acode si aún no está instalado:

```sh
apk update && apk add git
```

Configura tu identidad de Git (usa tu nombre y correo de GitHub):

```sh
git config --global user.name "Tu nombre"
git config --global user.email "tu-correo@example.com"
```

Crea primero un repositorio vacío en https://github.com/new con el nombre `NEXUS-Launcher`. No marques README, .gitignore ni licencia.

Después, desde la raíz del proyecto ejecuta (reemplaza `TU_USUARIO` por tu usuario real de GitHub):

```sh
git init
git branch -M main
git add .
git commit -m "Primer commit NEXUS Launcher"
git remote add origin https://github.com/TU_USUARIO/NEXUS-Launcher.git
git push -u origin main
```

Cuando GitHub pida contraseña, utiliza un Personal Access Token de GitHub con acceso al repositorio y permiso **Contents: Read and write**. El token se pega en el campo de contraseña; no lo compartas con nadie ni lo publiques en el repositorio.

## Descargar el APK
1. Abre el repositorio en GitHub.
2. Entra en la pestaña **Actions**.
3. Abre el flujo **NEXUS Launcher Build** más reciente.
4. Espera a que aparezca el indicador verde de éxito.
5. Baja hasta **Artifacts** y descarga `NEXUS-Launcher-APK`.
6. Extrae ese ZIP; dentro estará `app-debug.apk`.
7. Toca el APK e instala. Si Android lo solicita, permite instalar aplicaciones desde esa fuente.
8. Para usarlo, pulsa Inicio y selecciona **NEXUS Launcher** como aplicación de inicio.

## Si algo falla
- Si Actions muestra una X roja, abre la ejecución y copia el primer error rojo completo.
- Si `git push` dice `Authentication failed`, genera un token nuevo con permiso `Contents: Read and write` y úsalo como contraseña.
- Si el terminal no encuentra `apk`, confirma que estás usando el terminal Alpine integrado de Acode.

## Estado de funciones
- Incluye pantalla de inicio oscura con acentos violeta, reloj y fecha, búsqueda y cuadrícula de aplicaciones.
- El widget musical y el visualizador son demostrativos en esta primera versión; todavía no controlan Spotify ni muestran datos reales de una sesión multimedia.
- Las etiquetas de alarma y clima son visuales; no son widgets conectados a datos reales.
