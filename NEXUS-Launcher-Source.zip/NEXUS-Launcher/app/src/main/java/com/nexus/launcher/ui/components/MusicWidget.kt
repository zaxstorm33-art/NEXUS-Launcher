package com.nexus.launcher.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Album
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun MusicWidget() {
    var playing by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF21182F), RoundedCornerShape(24.dp))
            .padding(18.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                Icons.Default.Album,
                contentDescription = "Carátula",
                tint = Color(0xFFD6A6FF),
                modifier = Modifier.padding(end = 12.dp)
            )
            Column(modifier = Modifier.weight(1f)) {
                Text("Ninguna canción conectada", color = Color.White)
                Text("Conecta una aplicación de música", color = Color.LightGray, fontSize = 12.sp)
            }
            Icon(Icons.Default.GraphicEq, contentDescription = "Ecualizador", tint = Color(0xFFAA55FF))
        }

        Spacer(Modifier.height(12.dp))
        AudioVisualizer(isPlaying = playing)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { }) {
                Icon(Icons.Default.SkipPrevious, contentDescription = "Anterior", tint = Color.White)
            }
            IconButton(onClick = { playing = !playing }) {
                Icon(
                    if (playing) Icons.Default.Pause else Icons.Default.PlayArrow,
                    contentDescription = if (playing) "Pausar demo" else "Animar visualizador",
                    tint = Color(0xFFD6A6FF)
                )
            }
            IconButton(onClick = { }) {
                Icon(Icons.Default.SkipNext, contentDescription = "Siguiente", tint = Color.White)
            }
        }
        LinearProgressIndicator(
            progress = { if (playing) 0.35f else 0f },
            modifier = Modifier.fillMaxWidth(),
            color = Color(0xFFAA55FF),
            trackColor = Color.DarkGray
        )
        Text(
            "Controles de demostración; aún no controlan Spotify.",
            color = Color.LightGray,
            fontSize = 10.sp,
            modifier = Modifier.padding(top = 7.dp)
        )
    }
}
