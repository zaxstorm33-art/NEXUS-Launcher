package com.nexus.launcher

import android.service.notification.NotificationListenerService

/**
 * Servicio base. El usuario debe habilitar el acceso a notificaciones
 * manualmente en los ajustes de Android.
 *
 * La conexión a MediaSessionManager y los controles multimedia reales
 * se añadirán en la siguiente etapa.
 */
class MediaAccessService : NotificationListenerService()
