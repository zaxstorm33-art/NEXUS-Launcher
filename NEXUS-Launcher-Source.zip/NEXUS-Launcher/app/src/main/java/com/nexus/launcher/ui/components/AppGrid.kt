package com.nexus.launcher.ui.components

import android.content.Intent
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.painter.BitmapPainter
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap

private data class LauncherApp(
    val name: String,
    val packageName: String,
    val icon: android.graphics.drawable.Drawable
)

@Composable
fun AppGrid(searchQuery: String) {
    val context = LocalContext.current

    val apps = remember(context) {
        val launcherIntent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        context.packageManager.queryIntentActivities(launcherIntent, 0)
            .map { resolveInfo ->
                LauncherApp(
                    name = resolveInfo.loadLabel(context.packageManager).toString(),
                    packageName = resolveInfo.activityInfo.packageName,
                    icon = resolveInfo.loadIcon(context.packageManager)
                )
            }
            .distinctBy { it.packageName }
            .sortedBy { it.name.lowercase() }
    }

    val filtered = apps.filter { it.name.contains(searchQuery, ignoreCase = true) }

    Column(modifier = Modifier.fillMaxWidth()) {
        Text("Aplicaciones", color = Color.White, fontSize = 20.sp)
        Spacer(Modifier.height(12.dp))

        LazyVerticalGrid(
            columns = GridCells.Fixed(4),
            modifier = Modifier.fillMaxWidth().height(390.dp),
            userScrollEnabled = true,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            items(filtered, key = { it.packageName }) { app ->
                val painter = remember(app.packageName) {
                    BitmapPainter(app.icon.toBitmap(96, 96).asImageBitmap())
                }
                Column(
                    modifier = Modifier
                        .clickable {
                            context.packageManager.getLaunchIntentForPackage(app.packageName)
                                ?.let { launchIntent -> context.startActivity(launchIntent) }
                        }
                        .padding(vertical = 4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Image(
                        painter = painter,
                        contentDescription = app.name,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(Modifier.height(5.dp))
                    Text(
                        text = app.name,
                        color = Color.White,
                        fontSize = 11.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
        if (filtered.isEmpty()) {
            Text("No se encontraron aplicaciones", color = Color.LightGray)
        }
    }
}
