package com.nexus.launcher.ui.components

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryFull
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun QuickWidgets() {
    val context = LocalContext.current

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        QuickCard(
            modifier = Modifier.weight(1f),
            title = "Batería",
            subtitle = "Estado del dispositivo",
            icon = Icons.Default.BatteryFull,
            onClick = {
                context.startActivity(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS))
            }
        )
        QuickCard(
            modifier = Modifier.weight(1f),
            title = "Sistema",
            subtitle = "Ajustes Android",
            icon = Icons.Default.Settings,
            onClick = {
                context.startActivity(Intent(Settings.ACTION_SETTINGS))
            }
        )
    }
}

@Composable
private fun QuickCard(
    modifier: Modifier,
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit
) {
    Column(
        modifier = modifier
            .background(Color(0xFF21182F), RoundedCornerShape(20.dp))
            .clickable(onClick = onClick)
            .padding(14.dp)
    ) {
        Icon(icon, contentDescription = null, tint = Color(0xFFD6A6FF))
        Spacer(Modifier.height(8.dp))
        Text(title, color = Color.White)
        Text(subtitle, color = Color.LightGray, fontSize = 10.sp)
    }
}
