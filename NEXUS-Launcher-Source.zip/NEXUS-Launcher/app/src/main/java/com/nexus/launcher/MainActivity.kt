package com.nexus.launcher

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.Modifier
import com.nexus.launcher.ui.LauncherScreen
import com.nexus.launcher.ui.theme.NexusTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.statusBarColor = android.graphics.Color.rgb(8, 7, 16)
        window.navigationBarColor = android.graphics.Color.rgb(8, 7, 16)

        setContent {
            NexusTheme {
                LauncherScreen(modifier = Modifier.fillMaxSize())
            }
        }
    }
}
