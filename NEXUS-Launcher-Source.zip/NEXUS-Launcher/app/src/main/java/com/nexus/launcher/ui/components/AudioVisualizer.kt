package com.nexus.launcher.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlin.random.Random

@Composable
fun AudioVisualizer(isPlaying: Boolean) {
    val levels = remember { mutableStateListOf<Float>().apply { repeat(28) { add(0.15f) } } }

    LaunchedEffect(isPlaying) {
        while (isPlaying) {
            levels.indices.forEach { index ->
                levels[index] = Random.nextFloat() * 0.8f + 0.2f
            }
            delay(120)
        }
        if (!isPlaying) {
            levels.indices.forEach { levels[it] = 0.15f }
        }
    }

    Row(
        modifier = Modifier.fillMaxWidth().height(42.dp),
        horizontalArrangement = Arrangement.spacedBy(3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        levels.forEach { level ->
            androidx.compose.foundation.layout.Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight(level)
                    .background(Color(0xFFAA55FF), RoundedCornerShape(8.dp))
            )
        }
    }
}
