package com.nexus.launcher.ui.theme

import androidx.compose.ui.graphics.Color

val Background = Color(0xFF080710)
val SurfaceDark = Color(0xFF171224)
val NeonPurple = Color(0xFFAA55FF)
val NeonLight = Color(0xFFD6A6FF)
val TextWhite = Color(0xFFF8F5FF)
val TextGray = Color(0xFFAAA3B8)
val Glass = Color(0xFF211A32)
