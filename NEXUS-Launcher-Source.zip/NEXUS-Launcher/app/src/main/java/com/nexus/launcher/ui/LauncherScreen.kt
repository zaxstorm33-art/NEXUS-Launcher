package com.nexus.launcher.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.nexus.launcher.ui.components.AppGrid
import com.nexus.launcher.ui.components.ClockWidget
import com.nexus.launcher.ui.components.MusicWidget
import com.nexus.launcher.ui.components.QuickWidgets
import com.nexus.launcher.ui.components.SearchBar

@Composable
fun LauncherScreen(modifier: Modifier = Modifier) {
    var search by remember { mutableStateOf("") }

    Box(
        modifier = modifier.background(Color(0xFF080710))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 18.dp, vertical = 22.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            SearchBar(
                value = search,
                onValueChange = { search = it }
            )
            ClockWidget()
            MusicWidget()
            AppGrid(searchQuery = search)
            QuickWidgets()
        }
    }
}
